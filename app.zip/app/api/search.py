from fastapi import APIRouter
from fastapi import Query
from fastapi import HTTPException
from app.dto.request.search_request import SearchRequest
from app.services.search.search_service import SearchService
import traceback
from app.config.logging import logger
from app.repository.search_repository import SearchRepository
from app.services.assistant.assistant_service import AssistantService
from typing import Optional

router = APIRouter(
    prefix="/api/cv-service/search",
    tags=["Candidate Search"],
)
assistant_service = AssistantService()
search_service = SearchService()
search_repository = SearchRepository()


# All chats
@router.get(
    "/feed",
)
def search_history():
    return search_repository.get_all_search()

#Delete chat
@router.delete("/{search_id}")
def delete_search(search_id: str):
    return search_repository.delete_search(search_id)


# Search Candidates
@router.post("")
def search_candidates(
    request: SearchRequest,
    page: int = Query(
        default=1,
        ge=1,
    ),
    page_size: int = Query(
        default=20,
        ge=1,
        le=100,
    ),
):

    try:

        response = assistant_service.process(
            request=request,
            page=page,
            page_size=page_size,
        )

        return response

    except HTTPException:
        raise

    except Exception as e:

        logger.info("=" * 80)
        logger.info(traceback.format_exc())
        logger.info("=" * 80)
        raise HTTPException(
            status_code=500,
            detail=str(e),
        )

# Get Search Results
@router.get(
    "/job/{search_id}/conversation/{conversation_id}",
)
def get_search_results(
    search_id: str,
    conversation_message_id: Optional[str] = None,
):
    results = search_repository.get_search_results(
        search_id=search_id,
        conversation_message_id=conversation_message_id,
    )

    if len(results) == 0:
        raise HTTPException(
            status_code=404,
            detail="Search Results Not Found.",
        )

    return {
        "search_id": search_id,
        "conversation_message_id": conversation_message_id,
        "total_candidates": len(results),
        "results": results,
    }

#Get each chat
@router.get(
    "/job/{search_id}",
)
def get_chat(search_id: str):

    conversation = search_repository.get_chat(search_id)

    if conversation is None:

        raise HTTPException(
            status_code=404,
            detail="Conversation not found."
        )

    return conversation
# Candidate Reasoning
@router.get(
    "/job/{search_id}/profile/{profile_id}",
)
def get_reasoning(
    search_id: str,
    profile_id: str,
):
    try:
        return search_service.get_candidate_reasoning(
            search_id,
            profile_id,
        )
    except Exception as e:
        logger.exception(e)
        traceback.print_exc()
        raise HTTPException(
            status_code=500,
            detail=str(e),
        )


@router.get(
    "/job/{search_id}",
)
def get_conversation(
    search_id: str,
):

    assistant = AssistantService()

    return assistant.get_conversation_history(
        search_id,
    )