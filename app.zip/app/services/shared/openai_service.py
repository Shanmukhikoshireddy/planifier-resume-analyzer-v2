import json
import time
from openai import OpenAI
from app.config.settings import settings
from app.config.logging import logger

class OpenAIService:
    def __init__(self):
        logger.info("Initializing OpenAI...")
        self.client = OpenAI(
            api_key=settings.OPENAI_API_KEY,
        )
        self.model = settings.OPENAI_MODEL
        logger.info(
            f"OpenAI Model : {self.model}"
        )
    def generate(
        self,
        messages,
        json_mode: bool = False,
        max_tokens: int = 1200,
    ) -> str:
        try:
            for attempt in range(3):
                try:
                    kwargs = {
                        "model": self.model,
                        "messages": messages,
                        "temperature": 0,
                        "max_tokens": max_tokens,
                    }

                    if json_mode:
                        kwargs["response_format"] = {
                            "type": "json_object",
                        }

                    response = self.client.chat.completions.create(
                        **kwargs
                    )
                    content = response.choices[0].message.content
                    return content.strip()
                except Exception as e:
                    logger.warning(
                        f"OpenAI attempt {attempt + 1} failed."
                    )
                    logger.exception(e)
                    if attempt == 2:
                        raise
                    time.sleep(2)
        except Exception as e:
            logger.exception(e)
            raise
    def generate_json(
        self,
        messages,
    ) -> dict:

        response = self.generate(
            messages,
            json_mode=True,
        )

        logger.info(
            f"OPENAI RAW RESPONSE TYPE: {type(response).__name__}"
        )

        logger.info(
            f"OPENAI RAW RESPONSE: {response}"
        )

        if response is None:
            raise ValueError(
                "OpenAI returned an empty response."
            )

        if not isinstance(response, str):
            raise ValueError(
                "OpenAI response is not a string."
            )

        response = response.strip()

        if not response:
            raise ValueError(
                "OpenAI returned an empty response."
            )

        # Remove markdown fences if present
        if response.startswith("```"):

            response = response.replace(
                "```json",
                "",
            )

            response = response.replace(
                "```",
                "",
            )

            response = response.strip()

        # Extract JSON object
        start = response.find("{")
        end = response.rfind("}")

        if start == -1 or end == -1:

            logger.error(
                "No JSON object found in OpenAI response."
            )

            logger.error(
                f"Response: {response}"
            )

            raise ValueError(
                "Invalid JSON returned by OpenAI."
            )

        response = response[
            start:end + 1
        ]

        try:

            parsed = json.loads(
                response
            )

            logger.info(
                f"PARSED OPENAI JSON: {parsed}"
            )

            return parsed

        except json.JSONDecodeError as e:

            logger.error(
                "OpenAI returned invalid JSON."
            )

            logger.error(
                f"Response: {response}"
            )

            logger.exception(e)

            raise ValueError(
                "Invalid JSON returned by OpenAI."
            )
    # Health Check
    def health_check(self) -> bool:
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": "Reply with exactly OK."
                    }
                ],
            )

            text = response.choices[0].message.content.strip()

            logger.info(f"Health Check Response: {text}")

            return text.upper() == "OK"

        except Exception as e:
            logger.exception("OpenAI Health Check Failed")
            return False