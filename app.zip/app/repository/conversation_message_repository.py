from datetime import datetime
from bson import ObjectId
from app.config.logging import logger
from app.repository.base_repository import BaseRepository
from app.utils.datetime_utils import utc_now

class ConversationMessageRepository(BaseRepository):

    def __init__(self):
        super().__init__()
        self.collection = self.db["conversation_messages"]

    ####################################################
    # Create Conversation Message
    ####################################################

    def create_message(
        self,
        search_id: str,
        user_prompt: str,
        intent: str,
        assistant_message: str = "",
        metadata: dict | None = None,
    ):

        document = {

            "search_id": ObjectId(search_id),

            "user_prompt": user_prompt,

            "intent": intent,

            "assistant_message": assistant_message,

            "metadata": metadata or {},

            "created_at": utc_now(),

            "updated_at": utc_now(),

        }

        result = self.collection.insert_one(document)

        return str(result.inserted_id)
    

    ####################################################
    # Conversation History
    ####################################################

    def get_messages(
        self,
        search_id: str,
    ):

        messages = list(

            self.collection.find(
                {
                    "search_id": ObjectId(search_id),
                }
            ).sort(
                "created_at",
                1,
            )
        )

        for message in messages:
            message["_id"] = str(message["_id"])
            message["search_id"] = str(message["search_id"])

        return messages


    def update_message(
        self,
        message_id: str,
        assistant_message: dict,
    ):
        self.collection.update_one(
            {
                "_id": ObjectId(message_id),
            },
            {
                "$set": {
                    "assistant_message": assistant_message,
                    "updated_at": utc_now(),
                }
            },
        )


    